# Amazon Product Reviews — Sentiment Analysis
### Complete Project Guide (with Viva Preparation Notes)

---

## 📁 Project Structure

```
amazon_sentiment_analysis.py   ← Main Python file (all-in-one)
amazon_reviews.csv             ← Your dataset (place here)
sentiment_model.pkl            ← Auto-created after first training run
confusion_matrix.png           ← Auto-created after evaluation
```

---

## ⚡ Quick Start

### Google Colab
```python
# 1. Upload amazon_sentiment_analysis.py to Colab
# 2. Run the cell below

!pip install nltk scikit-learn pandas numpy matplotlib seaborn
!python amazon_sentiment_analysis.py
```

### Local Machine
```bash
pip install nltk scikit-learn pandas numpy matplotlib seaborn
python amazon_sentiment_analysis.py
```

### Dataset
Download from Kaggle: **Amazon Consumer Reviews of Amazon Products**  
https://www.kaggle.com/datasets/datafiniti/consumer-reviews-of-amazon-products

Set `DATASET_PATH = "your_file.csv"` in `main()`.  
Leave it as `None` to run with the built-in demo dataset.

---

## 🏗️ Pipeline Overview

```
Raw CSV
  ↓
load_dataset()          → validate columns, drop NaN
  ↓
assign_sentiment()      → ratings 1-2 → 0 (Neg), 4-5 → 1 (Pos), drop 3
  ↓
preprocess_dataframe()  → lowercase, strip URLs/HTML/numbers/punct, stopwords
  ↓
TF-IDF Vectorizer       → sparse numeric matrix, n-grams (1,2)
  ↓
LinearSVC               → margin-maximising classifier
  ↓
Evaluate                → accuracy, F1, confusion matrix
  ↓
predict_sentiment()     → "Positive ✅" / "Negative ❌"
```

---

## 🎓 Viva Q&A Preparation

### Q1: Why remove neutral (rating=3) reviews?
**A:** Rating 3 is ambiguous — it doesn't clearly signal positive or negative
sentiment. Including it would introduce label noise, confusing the model and
reducing classification accuracy. Binary classification (0 vs 1) is cleaner
and more reliable.

### Q2: Why use TF-IDF instead of simple word counts (Bag-of-Words)?
**A:** Plain word counts give high weight to common words like "the", "is",
"product" that appear everywhere and carry no signal. TF-IDF downweights these
by dividing by how many documents they appear in (IDF part), so rare but
discriminative words like "defective" or "superb" score higher.

### Q3: What do n-grams (1,2) add?
**A:** Bigrams capture two-word phrases. "not good" as a bigram is strongly
Negative — but as individual words "not" (stopword) gets removed and "good"
alone looks Positive. Bigrams preserve this negation context.

### Q4: Why LinearSVC over Logistic Regression?
**A:** Both are strong linear classifiers. LinearSVC optimises a hinge loss
(margin maximisation) rather than log-loss. On high-dimensional sparse TF-IDF
vectors, SVM's margin geometry gives better generalisation. Empirically,
LinearSVC is 5–15% faster on large text datasets and matches or beats LR
in accuracy.

### Q5: Why stratified train-test split?
**A:** Amazon datasets are heavily imbalanced (4–5 star reviews dominate).
Without stratification, the test set might have very few Negative samples,
giving a misleadingly high accuracy. `stratify=y` ensures both splits mirror
the original class ratio.

### Q6: Why use a Pipeline?
**A:** A Pipeline chains preprocessing and modelling into one object. This
prevents **data leakage** — without it, you might accidentally fit the TF-IDF
on the full dataset (including test data), which artificially inflates scores.
The Pipeline fits only on training data and transforms test data separately.

### Q7: What does the confusion matrix tell us?
**A:**
```
                Predicted Negative  Predicted Positive
Actual Negative       TN                  FP
Actual Positive       FN                  TP
```
- **FP (False Positive):** Predicted Positive but actually Negative
- **FN (False Negative):** Predicted Negative but actually Positive
- High FP = model is too optimistic; high FN = model is too pessimistic

### Q8: When to use F1-score vs Accuracy?
**A:** On balanced datasets, accuracy is fine. When one class dominates
(e.g. 90% Positive), a model predicting "always Positive" gets 90% accuracy
but is useless. F1-score (harmonic mean of precision and recall) penalises
this and gives a fair picture of performance on the minority class.

### Q9: What is `sublinear_tf=True` in TF-IDF?
**A:** It replaces raw term frequency *tf* with *1 + log(tf)*. This dampens
the effect of very frequent words — "good" appearing 50 times in one review
isn't 50× more informative than appearing once. The log scale compresses this.

### Q10: What is `min_df=2`?
**A:** Terms that appear in fewer than 2 documents are likely typos or rare
noise. Removing them reduces vocabulary size and prevents overfitting to
training-set noise.

### Q11: How does `save_model / load_model` work?
**A:** Python's `pickle` module serialises the entire Pipeline object (TF-IDF
vocabulary + SVM weights) into a binary file. On reload, the file is
deserialised back into a ready-to-use Pipeline — no retraining needed.

### Q12: What preprocessing steps are applied and why?
| Step | Reason |
|------|--------|
| Lowercase | "Good" and "good" are the same word |
| Remove URLs | `http://...` carries no sentiment |
| Remove HTML tags | Leftover `<br>`, `<b>` from web scraping |
| Remove non-alpha | Numbers, punctuation add noise |
| Remove stopwords | "the", "is", "and" appear in all classes |
| Remove len < 3 | "ok", "i", "a" — too short to be informative |

---

## 📊 Expected Results (Real Amazon Dataset)
| Metric | Typical Value |
|--------|--------------|
| Accuracy | 92–96% |
| Positive F1 | 0.94–0.97 |
| Negative F1 | 0.82–0.90 |

*(Demo dataset will show higher scores due to clean synthetic text)*

---

## 🔧 Customisation Tips
- Increase `MAX_FEATURES` to 20,000 for richer vocabulary (uses more RAM)
- Try `C=0.5` or `C=2.0` in LinearSVC to tune regularisation
- Add lemmatization using `nltk.WordNetLemmatizer` for slightly better accuracy
- Use `GridSearchCV` to automate hyperparameter tuning

---

*Built for academic submission — modular, commented, and viva-ready.*
