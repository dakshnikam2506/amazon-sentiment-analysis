# =============================================================================
# AMAZON PRODUCT REVIEWS SENTIMENT ANALYSIS
# Author: ML Engineer
# Description: End-to-end sentiment analysis pipeline using TF-IDF + LinearSVC
# Compatible with: Google Colab, Jupyter Notebook, Local Python (3.7+)
# =============================================================================

# ─────────────────────────────────────────────────────────────────────────────
# STEP 0: Install Dependencies (Uncomment if running in Google Colab)
# ─────────────────────────────────────────────────────────────────────────────
# !pip install nltk scikit-learn pandas numpy matplotlib seaborn

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1: Import Libraries
# ─────────────────────────────────────────────────────────────────────────────
import os
import re
import pickle
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import nltk
from nltk.corpus import stopwords

from sklearn.svm import LinearSVC
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
)
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")

# Download required NLTK data
nltk.download("stopwords", quiet=True)
nltk.download("punkt", quiet=True)

# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────
MODEL_PATH = "sentiment_model.pkl"
RANDOM_STATE = 42
TEST_SIZE = 0.20
MAX_FEATURES = 10_000


# =============================================================================
# SECTION 1 — DATA LOADING & VALIDATION
# Why: Raw data must be verified before any processing. Missing columns or
#      corrupt values will silently break downstream steps.
# =============================================================================

def load_dataset(filepath: str) -> pd.DataFrame:
    """
    Load CSV dataset and validate required columns exist.

    Expected columns:
        - reviews.text   : raw review string
        - reviews.rating : integer 1–5

    Returns
    -------
    pd.DataFrame with only the two required columns, no NaN rows.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(
            f"Dataset not found at '{filepath}'.\n"
            "Download the Amazon product reviews CSV and update the path."
        )

    df = pd.read_csv(filepath, low_memory=False)

    required = {"reviews.text", "reviews.rating"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(
            f"Dataset is missing required columns: {missing}\n"
            f"Found columns: {list(df.columns)}"
        )

    # Keep only what we need
    df = df[["reviews.text", "reviews.rating"]].copy()

    # Drop rows where either column is null
    before = len(df)
    df.dropna(subset=["reviews.text", "reviews.rating"], inplace=True)
    after = len(df)
    print(f"[INFO] Dropped {before - after} rows with missing values.")
    print(f"[INFO] Dataset loaded — {after:,} rows remaining.")
    return df


# =============================================================================
# SECTION 2 — SENTIMENT LABEL CREATION
# Why: ML models need numeric target labels.
#      Rating 3 is ambiguous ("neutral"), so we drop it to keep classes clean.
#      This is standard practice in binary sentiment classification.
# =============================================================================

def assign_sentiment(df: pd.DataFrame) -> pd.DataFrame:
    """
    Convert numeric ratings to binary sentiment labels.

    Mapping:
        1, 2  →  0  (Negative)
        3     →  removed (neutral — ambiguous signal)
        4, 5  →  1  (Positive)

    Returns
    -------
    pd.DataFrame with a new 'sentiment' column (0 or 1).
    """
    # Coerce rating to numeric, drop non-numeric rows
    df["reviews.rating"] = pd.to_numeric(df["reviews.rating"], errors="coerce")
    df.dropna(subset=["reviews.rating"], inplace=True)
    df["reviews.rating"] = df["reviews.rating"].astype(int)

    # Remove neutral reviews
    before = len(df)
    df = df[df["reviews.rating"] != 3].copy()
    print(f"[INFO] Removed {before - len(df):,} neutral (rating=3) reviews.")

    # Map to binary label
    df["sentiment"] = df["reviews.rating"].apply(
        lambda r: 1 if r >= 4 else 0
    )

    counts = df["sentiment"].value_counts()
    print(f"[INFO] Positive samples: {counts.get(1, 0):,}")
    print(f"[INFO] Negative samples: {counts.get(0, 0):,}")
    return df


# =============================================================================
# SECTION 3 — TEXT PREPROCESSING
# Why: Raw text contains noise (HTML, punctuation, numbers, URLs) that adds
#      dimensionality without meaning. Stopwords ("the", "is", "and") appear
#      in every class and carry no discriminative signal.
#      Short words (<3 chars) are mostly noise or stopwords the list missed.
# =============================================================================

STOP_WORDS = set(stopwords.words("english"))


def clean_text(text: str) -> str:
    """
    Apply a standard NLP cleaning pipeline to a single review string.

    Steps
    -----
    1. Lowercase
    2. Remove URLs
    3. Remove HTML tags
    4. Remove non-alphabetic characters (numbers, punctuation, symbols)
    5. Tokenise by whitespace
    6. Remove stopwords
    7. Remove tokens shorter than 3 characters
    8. Rejoin into a single string
    """
    if not isinstance(text, str):
        return ""

    # 1. Lowercase
    text = text.lower()

    # 2. Remove URLs
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)

    # 3. Remove HTML tags
    text = re.sub(r"<.*?>", " ", text)

    # 4. Keep only alphabetic characters
    text = re.sub(r"[^a-z\s]", " ", text)

    # 5. Tokenise
    tokens = text.split()

    # 6 & 7. Remove stopwords and short words
    tokens = [
        word for word in tokens
        if word not in STOP_WORDS and len(word) >= 3
    ]

    return " ".join(tokens)


def preprocess_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Apply clean_text() to every review in the dataframe.
    Drops rows where the cleaned text is empty after processing.
    """
    print("[INFO] Preprocessing text — this may take a minute …")
    df = df.copy()
    df["clean_text"] = df["reviews.text"].apply(clean_text)

    before = len(df)
    df = df[df["clean_text"].str.strip() != ""]
    print(f"[INFO] Dropped {before - len(df)} empty-after-cleaning rows.")
    print(f"[INFO] Preprocessing complete. {len(df):,} reviews ready.")
    return df


# =============================================================================
# SECTION 4 — FEATURE ENGINEERING (TF-IDF)
# Why: ML models need numeric vectors, not strings.
#      TF-IDF weights terms by how informative they are across the corpus —
#      rare discriminative words score higher than ubiquitous ones.
#      N-grams (1,2) capture short phrases like "not good", "battery life",
#      which single words miss entirely.
# =============================================================================

def build_tfidf_vectorizer() -> TfidfVectorizer:
    """
    Create a TF-IDF vectorizer with project-standard parameters.

    Parameters
    ----------
    max_features : 10,000  — vocabulary cap to control memory & speed
    ngram_range  : (1,2)   — unigrams + bigrams
    sublinear_tf : True    — apply log(1+tf) to dampen term frequency
    min_df       : 2       — ignore terms that appear in < 2 docs (typos)
    """
    return TfidfVectorizer(
        max_features=MAX_FEATURES,
        ngram_range=(1, 2),
        sublinear_tf=True,
        min_df=2,
        strip_accents="unicode",
    )


# =============================================================================
# SECTION 5 — MODEL: LinearSVC
# Why LinearSVC over Logistic Regression?
# ┌─────────────────────┬─────────────────────┬──────────────────────┐
# │ Criterion           │ LinearSVC            │ Logistic Regression  │
# ├─────────────────────┼─────────────────────┼──────────────────────┤
# │ Optimisation        │ Hinge loss (margin)  │ Log-loss (prob.)     │
# │ High dimensions     │ Excellent            │ Good                 │
# │ Speed (large data)  │ Faster               │ Slower               │
# │ Sparse TF-IDF       │ Purpose-built        │ Works, not optimal   │
# │ Accuracy (NLP)      │ Usually higher       │ Slightly lower       │
# └─────────────────────┴─────────────────────┴──────────────────────┘
# LinearSVC maximises the margin between classes — on sparse, high-dimensional
# text vectors this geometrically translates to better generalisation.
# =============================================================================

def build_pipeline() -> Pipeline:
    """
    Combine TF-IDF vectorisation + LinearSVC into a single sklearn Pipeline.
    A Pipeline prevents data leakage: the vectoriser is fit only on training
    data and applied identically to test data.
    """
    return Pipeline([
        ("tfidf", build_tfidf_vectorizer()),
        ("clf",   LinearSVC(C=1.0, max_iter=2000, random_state=RANDOM_STATE)),
    ])


# =============================================================================
# SECTION 6 — TRAINING
# Why stratified split?
# Real Amazon datasets are imbalanced (far more 4–5 star reviews).
# Stratified sampling ensures both train and test sets preserve the original
# class ratio, giving a fair evaluation baseline.
# =============================================================================

def train_model(df: pd.DataFrame):
    """
    Split data, fit the pipeline, and return the trained model + split data.

    Returns
    -------
    pipeline, X_train, X_test, y_train, y_test
    """
    X = df["clean_text"]
    y = df["sentiment"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y,          # ← preserve class distribution
    )

    print(f"[INFO] Training on {len(X_train):,} samples …")
    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)
    print("[INFO] Training complete.")
    return pipeline, X_train, X_test, y_train, y_test


# =============================================================================
# SECTION 7 — EVALUATION
# Metrics explained:
#   Accuracy  — overall % correct (useful when classes are balanced)
#   Precision — of all predicted Positive, how many are really Positive?
#   Recall    — of all actual Positive, how many did we catch?
#   F1-Score  — harmonic mean of precision & recall (use when imbalanced)
#   Confusion Matrix — shows exact TP, FP, TN, FN counts visually
# =============================================================================

def evaluate_model(pipeline, X_test, y_test) -> None:
    """
    Print classification metrics and display a confusion matrix heatmap.
    """
    y_pred = pipeline.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    print("\n" + "=" * 55)
    print(f"  ACCURACY : {acc * 100:.2f}%")
    print("=" * 55)

    print("\nCLASSIFICATION REPORT:")
    print(classification_report(
        y_test, y_pred,
        target_names=["Negative", "Positive"]
    ))

    # ── Confusion Matrix ──────────────────────────────────────────
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(7, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=["Predicted Negative", "Predicted Positive"],
        yticklabels=["Actual Negative",    "Actual Positive"],
        linewidths=0.5,
    )
    plt.title("Confusion Matrix — Amazon Sentiment Analysis", fontsize=14, pad=14)
    plt.tight_layout()
    plt.savefig("confusion_matrix.png", dpi=150)
    plt.show()
    print("[INFO] Confusion matrix saved as 'confusion_matrix.png'.")


# =============================================================================
# SECTION 8 — MODEL PERSISTENCE (BONUS)
# Why pickle?
# Training large TF-IDF + SVM pipelines takes time. Saving allows reuse
# without retraining — critical in production deployments.
# =============================================================================

def save_model(pipeline, path: str = MODEL_PATH) -> None:
    """Serialise the trained pipeline to disk using pickle."""
    with open(path, "wb") as f:
        pickle.dump(pipeline, f)
    print(f"[INFO] Model saved → '{path}'")


def load_model(path: str = MODEL_PATH):
    """
    Load a previously saved pipeline from disk.
    Raises FileNotFoundError if the model file does not exist.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"No saved model found at '{path}'. Train the model first."
        )
    with open(path, "rb") as f:
        pipeline = pickle.load(f)
    print(f"[INFO] Model loaded from '{path}'.")
    return pipeline


# =============================================================================
# SECTION 9 — PREDICTION FUNCTION
# The core deliverable: given any free-text review, return a human-readable
# sentiment label. The same preprocessing pipeline ensures consistency between
# training-time and inference-time feature representations.
# =============================================================================

def predict_sentiment(text: str, pipeline) -> str:
    """
    Predict the sentiment of a single free-text review.

    Parameters
    ----------
    text     : raw review string (no preprocessing needed from caller)
    pipeline : trained sklearn Pipeline (TF-IDF + LinearSVC)

    Returns
    -------
    "Positive" or "Negative"
    """
    if not isinstance(text, str) or text.strip() == "":
        return "Invalid input — please enter a non-empty review."

    cleaned = clean_text(text)
    if cleaned.strip() == "":
        return "Could not extract meaningful text from the input."

    prediction = pipeline.predict([cleaned])[0]
    return "Positive ✅" if prediction == 1 else "Negative ❌"


# =============================================================================
# SECTION 10 — INTERACTIVE CONSOLE LOOP
# Allows the user to type reviews and receive instant predictions.
# Type 'quit' or 'exit' to stop.
# =============================================================================

def interactive_predict(pipeline) -> None:
    """Run an interactive console session for sentiment prediction."""
    print("\n" + "=" * 55)
    print("  AMAZON REVIEW SENTIMENT PREDICTOR")
    print("  Type a product review and press Enter.")
    print("  Type 'quit' or 'exit' to stop.")
    print("=" * 55 + "\n")

    while True:
        try:
            user_input = input("Enter review: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[INFO] Session ended.")
            break

        if user_input.lower() in {"quit", "exit", "q"}:
            print("[INFO] Exiting predictor. Goodbye!")
            break

        if not user_input:
            print("[WARN] Empty input. Please type a review.\n")
            continue

        result = predict_sentiment(user_input, pipeline)
        print(f"  → Sentiment: {result}\n")


# =============================================================================
# SECTION 11 — DEMO MODE (for Colab / when no CSV is available)
# Generates a small synthetic dataset so the pipeline can be demonstrated
# without downloading the full Amazon dataset.
# =============================================================================

def generate_demo_data(n_per_class: int = 500) -> pd.DataFrame:
    """
    Build a tiny synthetic dataset to demo the pipeline end-to-end.
    Replace this with the real CSV path in production.
    """
    positive_templates = [
        "This product is absolutely amazing, highly recommend it to everyone",
        "Excellent quality and fast shipping, very satisfied with my purchase",
        "Works perfectly, great value for money, will buy again",
        "Outstanding product, exceeded all my expectations, love it",
        "Best purchase I have made this year, quality is superb",
        "Fantastic build quality, arrived quickly, exactly as described",
        "Really happy with this item, it works flawlessly and looks great",
        "Top notch product, customer service was also very helpful",
        "Very durable and well made, totally worth every penny spent",
        "Incredible product, my whole family loves it, five stars",
    ]
    negative_templates = [
        "Terrible product, broke after two days, complete waste of money",
        "Very disappointed with this purchase, quality is extremely poor",
        "Does not work as advertised, returning it immediately for refund",
        "Cheap and flimsy construction, fell apart within first week",
        "Awful experience, product arrived damaged and customer service ignored me",
        "Total junk, nothing like the description, do not buy this",
        "Stopped working after one use, absolute garbage, worst purchase ever",
        "Extremely poor quality, instructions are useless and parts are missing",
        "Waste of money, looks nothing like the pictures on the listing",
        "Defective out of the box, seller was unhelpful and rude",
    ]

    rng = np.random.default_rng(RANDOM_STATE)
    pos_texts = [positive_templates[i % len(positive_templates)] for i in range(n_per_class)]
    neg_texts = [negative_templates[i % len(negative_templates)] for i in range(n_per_class)]

    texts   = pos_texts + neg_texts
    ratings = [5] * n_per_class + [1] * n_per_class

    df = pd.DataFrame({
        "reviews.text":   texts,
        "reviews.rating": ratings,
    })
    df = df.sample(frac=1, random_state=RANDOM_STATE).reset_index(drop=True)
    print(f"[INFO] Demo dataset generated — {len(df):,} synthetic reviews.")
    return df


# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

def main():
    print("\n" + "█" * 55)
    print("  AMAZON PRODUCT REVIEWS — SENTIMENT ANALYSIS")
    print("  Linear SVM + TF-IDF Pipeline")
    print("█" * 55 + "\n")

    # ── Choose data source ────────────────────────────────────────
    # Set DATASET_PATH to your CSV file path.
    # Leave as None to run with the built-in demo dataset.
    DATASET_PATH = None   # e.g. "amazon_reviews.csv"

    pipeline = None

    # ── Option A: Load pre-trained model ─────────────────────────
    if os.path.exists(MODEL_PATH):
        load_existing = input(
            f"[PROMPT] Saved model found at '{MODEL_PATH}'. "
            "Load it? (y/n): "
        ).strip().lower()
        if load_existing == "y":
            pipeline = load_model(MODEL_PATH)

    # ── Option B: Train fresh model ───────────────────────────────
    if pipeline is None:
        # 1. Load / generate data
        if DATASET_PATH:
            df = load_dataset(DATASET_PATH)
        else:
            print("[INFO] No dataset path set — using demo data.\n")
            df = generate_demo_data(n_per_class=600)

        # 2. Assign sentiment labels
        df = assign_sentiment(df)

        # 3. Preprocess text
        df = preprocess_dataframe(df)

        # 4. Train
        pipeline, X_train, X_test, y_train, y_test = train_model(df)

        # 5. Evaluate
        evaluate_model(pipeline, X_test, y_test)

        # 6. Save model (optional)
        save_choice = input(
            "\n[PROMPT] Save the trained model for future use? (y/n): "
        ).strip().lower()
        if save_choice == "y":
            save_model(pipeline)

    # ── Quick demo predictions ────────────────────────────────────
    demo_reviews = [
        "This product is absolutely fantastic, I love it!",
        "Terrible quality, broke after one day. Waste of money.",
        "Battery life is great and the sound quality is superb.",
        "Does not work at all. Very disappointed with this purchase.",
    ]
    print("\n── Quick Demo Predictions ──────────────────────────────")
    for review in demo_reviews:
        label = predict_sentiment(review, pipeline)
        print(f"  Review : {review[:60]}…")
        print(f"  Result : {label}\n")

    # ── Interactive mode ──────────────────────────────────────────
    go_interactive = input(
        "[PROMPT] Enter interactive prediction mode? (y/n): "
    ).strip().lower()
    if go_interactive == "y":
        interactive_predict(pipeline)

    print("\n[INFO] Program complete. Thank you!")


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    main()
